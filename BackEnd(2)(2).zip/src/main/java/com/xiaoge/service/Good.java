package com.xiaoge.service;

import java.util.List;

public interface Good {

    public List<Good> queryUserList();

}
